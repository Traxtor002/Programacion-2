import java.util.HashMap;
import java.util.Map;

public class Parqueadero {

    private final int SIZE = 40;
    private final int NO_STALL = 1;
    private final int CLOSE_PARKING = -2;
    private final int NO_EXIST_CAR = -3;
    private final int EXIST_CAR= -4;
    private final int INICIAL_TIME = 6;
    private final int CLOSE_TIME = 20;
    private final int INICIAL_FEE = 1200;

    private int fee;
    private int cash;
    private int actualTime;
    private boolean open;
    private Map<String, Integer> carsinParking;

    public Parqueadero() {
        this.fee = INICIAL_FEE;
        this.cash = 0;
        this.actualTime = INICIAL_TIME;
        this.open = true;
        this.carsinParking = new HashMap<>();
    }

    public void givePlate(String plate) {
        carsinParking.put(plate, 0);
    }

    public int cargetIn(String plate) {
        if (!open) {
            return CLOSE_PARKING;
        } else if (carsinParking.containsKey(plate)) {
            return EXIST_CAR;
        } else if (calculatefreeParks() == 0) {
            return NO_STALL;
        } else {
            int puestoLibre = searchfreeSpace();
            carsinParking.put(plate, puestoLibre);
            return puestoLibre;
        }
    }

    public int cagetOut(String plate) {
        if (!carsinParking.containsKey(plate)) {
            return NO_EXIST_CAR;
        } else {
            int puesto = carsinParking.get(plate);
            carsinParking.remove(plate);
            return puesto;
        }
    }

    public void giveamoutCash(int amount) {
        cash += amount;
    }

    public int calculatefreeParks() {
        return SIZE - carsinParking.size();
    }

    public void changeFee(int newFee) {
        fee = newFee;
    }

    public int searchfreeSpace() {
        for (int i = 1; i <= SIZE; i++) {
            if (!carsinParking.containsValue(i)) {
                return i;
            }
        }
        return -1;
    }

    public int rweovecarCost(String plate, int parkTime) {
        if (!carsinParking.containsKey(plate)) {
            return NO_EXIST_CAR;
        } else {
            int slot = carsinParking.get(plate);
            carsinParking.remove(plate);
            int cost = calculateCost(parkTime);
            cash += cost;
            return cost;
        }
    }

    private int calculateCost(int hours) {
        return fee * hours;
    }

    public void advanceTime() {
        actualTime = (actualTime + 1) % 24;
    }

    public int giveActualTime() {
        return actualTime;
    }

    public boolean itsOpen() {
        return (actualTime >= INICIAL_TIME && actualTime < CLOSE_TIME);
    }

    public int giveFee() {
        return fee;
    }

    public boolean istTaken(int puesto) {
        return carsinParking.containsValue(puesto);
    }

    public String metodo10() {
        return "Metodo # 10";
    }

    public String metodo20() {
        return "Metodo # 20";
    }
}