public class Puesto extends Parqueadero {

    private Carro carro;
    private int parkingNumber;

    public Puesto(int slot) {
        carro = null;
        parkingNumber = slot;
    }

    public Carro giveCar() {
        return carro;
    }

    public boolean itsTaken() {
        return carro != null;
    }

    public void parkCar(Carro pCarro) {
        carro = pCarro;
    }

    public void sacarCarro() {
        carro = null;
    }

    public int darNumeroPuesto() {
        return parkingNumber;
    }

    public boolean tieneCarroConPlaca(String pPlaca) {
        if (carro == null) {
            return false;
        } else {
            return carro.tienePlaca(pPlaca);
        }
    }
}