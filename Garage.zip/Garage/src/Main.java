public class Main{
    public static void main(String[] args) {
        // Creación de un parqueadero
        Parqueadero parqueadero = new Parqueadero();

        // Creación de algunos carros y asignación a puestos
        Carro carro1 = new Carro("TBJ 4356", 7);
        Carro carro2 = new Carro("PCY 5430", 11);

        Puesto puesto1 = new Puesto(1);
        Puesto puesto2 = new Puesto(2);

        puesto1.parkCar(carro1);
        puesto2.parkCar(carro2);


        int actualTime =12;
        System.out.println("Hora actual: " + actualTime);
        System.out.println("Puesto #1 ocupado: " + puesto1.itsTaken());
        System.out.println("Puesto #2 ocupado: " + puesto2.itsTaken());


        puesto1.sacarCarro();
        int tiempoEnParqueadero = carro1.darTiempoEnParqueadero(actualTime);
        System.out.println("Carro 1 ha estado " + tiempoEnParqueadero + " horas en el parqueadero.");


        String searchPlate = "PCY 5430";
        boolean carroEnPuesto2 = puesto2.tieneCarroConPlaca(searchPlate);
        System.out.println("¿El carro de placa " + searchPlate + " está en el puesto 2? " + carroEnPuesto2);
    }
}