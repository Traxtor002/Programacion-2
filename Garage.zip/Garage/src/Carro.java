public class Carro extends Puesto {

    private String plate;
    private int arriveTime;

    public Carro(String pPlaca, int pHora) {
        super(0);
        plate = pPlaca;
        arriveTime = pHora;
    }

    public String givePlate() {
        return plate;
    }

    public int givearriveTime() {
        return arriveTime;
    }

    public boolean isPlate(String pPlaca) {
        return plate.equalsIgnoreCase(pPlaca);
    }

    public int givetimeinPark(int pHoraSalida) {
        int parkingTime = pHoraSalida - arriveTime + 1;
        return parkingTime;
    }
}